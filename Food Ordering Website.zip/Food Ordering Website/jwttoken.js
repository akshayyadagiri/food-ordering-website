const crypto = require('crypto');

function base64urlEncode(data) {
    const base64 = Buffer.from(JSON.stringify(data)).toString('base64');
    return base64
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
}

function generateJWT(payload, secretKey, expiresIn = '1h') {
    const header = {
        alg: 'HS256',
        typ: 'JWT'
    };

    const encodedHeader = base64urlEncode(header);
    const encodedPayload = base64urlEncode(payload);

    const signatureInput = `${encodedHeader}.${encodedPayload}`;
    const signature = signHS256(signatureInput, secretKey);

    const jwt = `${signatureInput}.${signature}`;
    return jwt;
}

function signHS256(data, key) {
    return crypto.createHmac('sha256', key)
        .update(data)
        .digest('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
}

// Example usage
const payload = {
    userId: '123456',
    username: 'example_user'
};

const secretKey = 'your_secret_key';
const token = generateJWT(payload, secretKey);

console.log(token);
